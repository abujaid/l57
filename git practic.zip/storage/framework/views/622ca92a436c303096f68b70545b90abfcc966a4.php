<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>Create Secrets</h1>
        <?php echo $__env->make('admin.include.message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo e(url('admin/secrets')); ?>">Secret</a></li>
            <li class="active">Create</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title">Add Secret</h3>
            </div>
            <form role="form" method="post" enctype="multipart/form-data" action="<?php echo e(url('admin/create-secrets')); ?>">
                <?php echo csrf_field(); ?>
                <div class="box-body">
                    <div class="form-group">
                        <label for="secret">Secret Text<span class="asterisk">*</span></label>
                        <textarea name="post_text" id="" cols="30" rows="10" class="form-control" placeholder="Add Secret Text"><?php echo e(old('post_text')); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="img">Secret Image</label>
                        <input type="file" name="post_image" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="img">Color</label>
                        <input type="color" name="color" value="<?php echo e(old('color')); ?>">
                    </div>
                     <label for="img">City Name<span class="asterisk">*</span></label>
                    <div class="form-group">
                        <select name="city_name" id="" class="form-control">
                            <option value="">--Choose City--</option>
                            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($city->latitude.','.$city->longitude); ?>" ><?php echo e($city->city_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                </div>
                <div class="box-footer">
                    <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>