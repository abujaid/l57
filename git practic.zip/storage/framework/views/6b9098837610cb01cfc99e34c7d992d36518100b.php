<?php $__env->startSection('title','Secrets'); ?>
<?php $__env->startSection('headSection'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css">
<style>
    a.paginate_button {
        margin-left: 5px;
        cursor: pointer;
    }

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>Secrets Page</h1>
        <?php echo $__env->make('admin.include.message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Secrets</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="table-responsive">
            <table class="table bg-primary table-responsive" id="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Secret Title</th>
                        <th>Tag Color</th>
                        <th>Latitude</th>
                        <th>Longitude</th>
                        <th>Created at</th>
                        <th class="nosort">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $secrets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secret): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->index + 1); ?></td>
                        <td><?php echo e(str_limit($secret->post_text,20)); ?></td>
                        <td><?php echo e($secret->color); ?></td>
                        <td><?php echo e($secret->latitude); ?></td>
                        <td><?php echo e($secret->longitude); ?></td>
                        <td><?php echo e($secret->created_at->format('Y-m-d')); ?></td>
                        <td>
                           
                            <form id="delete-form-<?php echo e($secret->id); ?>" method="post" action="<?php echo e(url('admin/secrets',$secret->id)); ?>"
                                style="display: none">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                            </form>
                            <a href="javascript:void(0);" onclick="
                    if(confirm('Are you sure, You Want to delete this?'))
                    {
                        event.preventDefault();
                        document.getElementById('delete-form-<?php echo e($secret->id); ?>').submit();
                    }
                    else{
                    event.preventDefault();
                    }"><span class="glyphicon glyphicon-trash btn btn-danger"></span></a>
                        </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </section>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footerSection'); ?>
<script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>

<script>
    $(document).ready(function () {
        $('#table').DataTable();
    });
    var table = $('#table').DataTable({
   'aoColumnDefs': [{
        'bSortable': false,
        'aTargets': ['nosort']
    }]
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>