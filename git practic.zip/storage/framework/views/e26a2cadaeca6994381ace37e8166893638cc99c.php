<?php $__env->startComponent('mail::message'); ?>
# Hello, <?php echo e($name); ?>


Your Password reset token is - <a href="<?php echo e(url('/password/reset/'.$token)); ?>">Reset Password</a>



Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
