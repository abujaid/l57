<?php $__env->startSection('title','City'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1><?php echo e($page_title); ?></h1>
    <?php echo $__env->make('admin.include.message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <ol class="breadcrumb">
      <li><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="<?php echo e(url('admin/city')); ?>">City</a></li>
      <li class="active">Edit</li>
    </ol>
  </section>

  <!-- Main content -->
        <section class="content">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title"><?php echo e($page_title); ?></h3>
            </div>
            <form role="form" method="post" action="<?php echo e(url('admin/city',$cities->id)); ?>">
              <?php echo csrf_field(); ?>
              <?php echo method_field('PUT'); ?>
              <div class="box-body">
                <div class="form-group">
                  <label for="cityName">City Name</label>
                  <input type="text" name="city_name" class="form-control" id="city_name" value="<?php echo e($cities->city_name); ?>">
                </div>
                <div class="form-group">
                  <label for="Latitude">Latitude</label>
                  <input type="text" name="latitude" class="form-control" id="latitude" value="<?php echo e($cities->latitude); ?>">
                </div>
                <div class="form-group">
                  <label for="Longitude">Longitude</label>
                  <input type="text" name="longitude" class="form-control" id="longitude" value="<?php echo e($cities->longitude); ?>">
                </div>
              </div>
              <div class="box-footer">
                <button type="submit" name="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
          </div>
        </section>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>