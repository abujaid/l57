<?php $__env->startSection('title','Users'); ?>
<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>User Details</h1>
    <ol class="breadcrumb">
      <li><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">User</li>
    </ol>
  </section>

  <!-- Main content -->

  <section class="content">
    <?php if(count($posts) > 1): ?>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="box box-widget">
      <div class="box-header with-border">
        <div class="user-block">
          <!-- <img class="img-circle" src="<?php echo e(asset('dist/img/user1-128x128.jpg')); ?>" alt="User Image"> -->
          <!-- <div class="img-circle"><?php echo e($userName->username); ?></div> -->
          <span class="username"><a href="javascript:void(0);"><?php echo e($userName->username); ?></a></span>
          <span class="description">Shared publicly - <?php echo e($post->created_at->diffForHumans()); ?></span>
        </div>
        <div class="box-tools">

          <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
          </button>
        </div>
      </div>
      <div class="box-body" style="">
        <div class="row">
          <div class="col-sm-4 col-md-4">
            <?php if($post->post_image): ?>
            <img class="img-responsive pad" src="<?php echo e(asset($post->post_image)); ?>">
            <?php else: ?>
            <img class="img-responsive pad" src="<?php echo e(asset('images/img/noimage.gif')); ?>">
            <?php endif; ?>
          </div>
          <div class="col-sm-8 col-md-8">
            <p><?php echo $post->post_text; ?></p>
          </div>
        </div>
        <span class="pull-right text-muted"><?php echo e($post->likes_count); ?> likes - <?php echo e($post->comments_count); ?> comments</span>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="text-right">
      <?php echo e($posts->links()); ?>

    </div>
    <?php else: ?>
    <div class="text-center">
      <h3>I don't have any records!</h3>
    </div>
    <?php endif; ?>
  </section>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>