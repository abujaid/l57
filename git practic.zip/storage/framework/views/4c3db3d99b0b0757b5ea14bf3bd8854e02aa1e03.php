    <?php if(Session::has('success')): ?>
        <div class="alert alert-success alert-dismissable custom-success-box" style="margin-top: 15px;">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <p> <?php echo e(Session('success')); ?> </p>
        </div>
    <?php endif; ?>
        <?php if(Session::has('error')): ?>
        <div class="alert alert-danger alert-dismissable custom-success-box" style="margin-top: 15px;">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <p> <?php echo e(Session('error')); ?> </p>
        </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissable custom-success-box" style="margin-top: 15px;">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>  
    <?php endif; ?>