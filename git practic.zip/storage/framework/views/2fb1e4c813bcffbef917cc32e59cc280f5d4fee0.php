<?php $__env->startSection('title','City'); ?>
<?php $__env->startSection('content'); ?>
   <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Create City</h1>
        <?php echo $__env->make('admin.include.message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <ol class="breadcrumb">
        <li><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo e(url('admin/city')); ?>">City</a></li>
        <li class="active">Create</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Add City<span class="asterisk">*</span></h3>
            </div>
            <form role="form" method="post" action="<?php echo e(url('admin/city')); ?>">
            <?php echo csrf_field(); ?>
              <div class="box-body">
                <div class="form-group">
                  <label for="cityName">City Name</label>
                  <input type="text" name="city_name" class="form-control" id="city_name" placeholder="Enter city" value="<?php echo e(old('city_name')); ?>">
                </div>
                <div class="form-group">
                  <label for="cityName">City Radius</label>
                  <input type="text" name="city_radius" class="form-control" id="city_radius" placeholder="Enter radius" value="<?php echo e(old('city_radius')); ?>">
                </div>
                <div class="form-group">
                  <label for="Latitude">Latitude<span class="asterisk">*</span></label>
                  <input type="text" name="latitude" class="form-control" id="latitude" placeholder="Latitude" value="<?php echo e(old('latitude')); ?>">
                </div>
                  <div class="form-group">
                  <label for="Longitude">Longitude<span class="asterisk">*</span></label>
                  <input type="text" name="longitude" class="form-control" id="longitude" placeholder="Longitude" value="<?php echo e(old('longitude')); ?>" >
                </div>
              </div>
              <div class="box-footer">
                <button type="submit" name="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
          </div>
    </section>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>