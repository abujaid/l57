<footer class="main-footer">
    <strong>Copyright &copy; <?php echo  Date('Y');?> <a href="javascript:void(0);">Spain Options</a>.</strong> All rights
    reserved.
</footer>