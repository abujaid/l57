<?php

/**
* @SWG\Swagger(
*     basePath="",
*     host="108.161.141.134",
*     schemes={"http","https"},
*     @SWG\Info(
*         version="1.0",
*         title="Spain Options",
*         @SWG\Contact(),
*     )
* )
**/
